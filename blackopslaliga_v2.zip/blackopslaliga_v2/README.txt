BLACKOPSLALIGA V2

Archivos:
- index.html: interfaz completa
- worker.js: backend Cloudflare Worker + D1

Funciones incluidas:
- Ligas 2v2, 3v3 y 4v4 independientes.
- Un usuario: máximo un clan por liga.
- Perfiles de jugador con PSN ID.
- Perfiles públicos de clanes con ID y jugadores.
- Ranking independiente por liga.
- Tablón compacto de retos.
- Ventana de aceptación de 30 minutos.
- Retos aceptados y resultados confirmados.
- Historial, chat, notificaciones.
- Reglas y botón atrás.
- Cuenta ADMIN por username "ADMIN" con gestión de usuarios, bloqueos, ranking y resultados.

IMPORTANTE: hacer backup de los archivos actuales y de la D1 antes de desplegar.
